//
//  ViewController.swift
//  Assignment1
//
//  Created by user239680 on 5/19/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var label1: UILabel!
    

    @IBAction func in1(_ sender: Any) {
    }
    
    
    @IBAction func in2(_ sender: Any) {
    }
    
    
    
    @IBAction func out(_ sender: Any) {
    }
    
    
    
    
    
    @IBAction func ac(_ sender: Any) {
    }
    
    
    @IBAction func percentage(_ sender: Any) {
    }
    
    @IBAction func raisetwo(_ sender: Any) {
    }
    
    @IBAction func div(_ sender: Any) {
    }
    
    
    @IBAction func mul(_ sender: Any) {
    }
    
    @IBAction func minus(_ sender: Any) {
    }
    
    
    @IBAction func plus(_ sender: Any) {
    }
    
    
    
    @IBAction func equlto(_ sender: Any) {
    }
    
    
    @IBAction func zero(_ sender: Any) {
    }
    
    @IBAction func dot(_ sender: Any) {
    }
    
    @IBAction func one(_ sender: Any) {
    }
    
    
    @IBAction func two(_ sender: Any) {
    }
    
    
    @IBAction func three(_ sender: Any) {
    }
    
    
    @IBAction func four(_ sender: Any) {
    }
    
    
    @IBAction func five(_ sender: Any) {
    }
    
    
    @IBAction func six(_ sender: Any) {
    }
    
    
    
    @IBAction func seven(_ sender: Any) {
    }
    
    
    
    @IBAction func eight(_ sender: Any) {
    }
    
    @IBAction func nine(_ sender: Any) {
    }
    
    
    
    
    
    
    
    
    
    
    
}

