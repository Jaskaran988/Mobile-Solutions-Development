import UIKit
import Foundation

// 1. Create a function named `twoSum` which accepts two integers and returns the sum of the two as a double.
func twoSum(_ x: Int, _ y: Int) -> Double {
    return Double(x + y)
}

// Test data for twoSum
print("twoSum(5, 8):", twoSum(5, 8))

// 2. Create a function named `studentExists` which accepts two variables, an array of strings and a name.
func studentExists(_ students: [String], _ name: String) -> Bool {
    return students.contains(name)
}

// Test data for studentExists
let students = ["Deep", "Karan", "Harman", "Gia"]
print("studentExists(students, 'Gia'):", studentExists(students, "Gia"))
print("studentExists(students, 'Karan'):", studentExists(students, "Karan"))

// 3. Create a function named `reduce` which accepts an array of Integers and returns the sum of all values in the array as an integer.
func reduce(_ numbers: [Int]) -> Int {
    return numbers.reduce(0, +)
}

// Test data for reduce
let numbers = [1, 2, 3, 4, 5, 7, 8]
print("reduce(numbers):", reduce(numbers))

// 4. Create a function to calculate the hypotenuse
func calculateHypotenuse(x: Double, y: Double) -> Double {
    return sqrt(x * x + y * y)
}

// Test data for calculateHypotenuse
print("calculateHypotenuse(x: 4, y: 6):", calculateHypotenuse(x: 4, y: 6))

// 5. Create a function named 'match' which accepts a key and returns a value from a dictionary
func match(_ key: String, in dictionary: [String: String]) -> String? {
    return dictionary[key]
}

// Test data for match
let dictionary = ["name": "Deep", "age": "20", "city": "Waterloo"]
print("match('name', in: dictionary):", match("name", in: dictionary) ?? "nil")
print("match('country', in: dictionary):", match("country", in: dictionary) ?? "nil")

